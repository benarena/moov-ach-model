# SegmentedFiles

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creditFileID** | **String** | File ID |  [optional]
**debitFileID** | **String** | File ID |  [optional]
