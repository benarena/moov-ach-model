# IATBatch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **String** | Client-defined string used as a reference to this record. |  [optional]
**iaTBatchHeader** | [**IATBatchHeader**](IATBatchHeader.md) |  | 
**iaTEntryDetails** | [**List&lt;IATEntryDetail&gt;**](IATEntryDetail.md) |  | 
**batchControl** | [**BatchControl**](BatchControl.md) |  | 
