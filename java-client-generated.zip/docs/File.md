# File

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **String** | File ID | 
**fileHeader** | [**FileHeader**](FileHeader.md) |  | 
**batches** | [**List&lt;Batch&gt;**](Batch.md) |  |  [optional]
**iaTBatches** | [**List&lt;IATBatch&gt;**](IATBatch.md) |  |  [optional]
**fileControl** | [**FileControl**](FileControl.md) |  | 
**notificationOfChange** | [**List&lt;Batch&gt;**](Batch.md) |  |  [optional]
**returnEntries** | [**List&lt;Batch&gt;**](Batch.md) |  |  [optional]
