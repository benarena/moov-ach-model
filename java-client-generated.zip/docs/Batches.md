# Batches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
