# Batch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**batchHeader** | [**BatchHeader**](BatchHeader.md) |  | 
**entryDetails** | [**List&lt;EntryDetail&gt;**](EntryDetail.md) |  | 
**batchControl** | [**BatchControl**](BatchControl.md) |  | 
**offset** | [**Offset**](Offset.md) |  | 
