# CreateFile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **String** | File ID |  [optional]
**fileHeader** | [**FileHeader**](FileHeader.md) |  | 
**batches** | [**List&lt;Batch&gt;**](Batch.md) |  |  [optional]
**iaTBatches** | [**List&lt;IATBatch&gt;**](IATBatch.md) |  |  [optional]
**fileControl** | [**FileControl**](FileControl.md) |  |  [optional]
**advEntryDetails** | [**List&lt;ADVEntryDetail&gt;**](ADVEntryDetail.md) |  |  [optional]
**advBatchControl** | [**ADVBatchControl**](ADVBatchControl.md) |  |  [optional]
