# ValidateOpts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requireABAOrigin** | **Boolean** | Require that the FileHeader ImmediateOrigin routing number which checksum matches. |  [optional]
**bypassOriginValidation** | **Boolean** | Skip ImmediateOrigin validation steps. |  [optional]
**bypassDestinationValidation** | **Boolean** | Skip ImmediateDestination validation steps. |  [optional]
