# FileID

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ID** | **String** | File ID |  [optional]
**error** | **String** | An error message describing the problem intended for humans. |  [optional]
